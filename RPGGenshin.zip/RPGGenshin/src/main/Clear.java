package main;

public class Clear {
    public static void clear() {
        for (int i = 0; i<20; i++) {
            System.out.println("\b");
        }
    }
}